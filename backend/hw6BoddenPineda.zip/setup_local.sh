#!/bin/bash
echo "Setting it up locally..."
npm install
