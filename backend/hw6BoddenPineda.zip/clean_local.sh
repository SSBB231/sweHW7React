#!/bin/bash
rm -r node_modules
